module.exports = {
	BOT_TOKEN: "Nzg1OTk0ODg0MzIyMTY0NzU2.X8_8xw.7HusP5CMhxTJpevoXETXKoROhBw",
	PREFIXE : "-lg",
}
