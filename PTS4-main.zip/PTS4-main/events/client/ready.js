  /**
  * Fonction permettant de confirmer le demarrage du bot
  * Mentionne le nom et tag du bot
  */
module.exports = bot => {
    console.log(`Lancement du bot ${bot.user.tag}`)
}